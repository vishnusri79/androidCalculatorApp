package com.example.finallogiccalci;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvNumber;
    TextView tvDetails;
    Calculator calculator;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculator = new Calculator();
        tvNumber = findViewById(R.id.tv_number);
        tvDetails = findViewById(R.id.tv_details);
    }

    public void numberClicked(View view) {
        int id = view.getId();
        if (id == R.id.b_0) {
            calculator.processNumber(0);
        } else if (id == R.id.b_1) {
            calculator.processNumber(1);
        } else if (id == R.id.b_2) {
            calculator.processNumber(2);
        } else if (id == R.id.b_3) {
            calculator.processNumber(3);
        } else if (id == R.id.b_4) {
            calculator.processNumber(4);
        } else if (id == R.id.b_5) {
            calculator.processNumber(5);
        } else if (id == R.id.b_6) {
            calculator.processNumber(6);
        } else if (id == R.id.b_7) {
            calculator.processNumber(7);
        } else if (id == R.id.b_8) {
            calculator.processNumber(8);
        } else if (id == R.id.b_9) {
            calculator.processNumber(9);
        }
        updateCalcUI();
    }



    public void updateCalcUI() {
        tvNumber.setText(calculator.numberString);
        tvDetails.setText(calculator.detailsString);

    }

    public void clearClicked(View view) {
        calculator.clearClicked();
        updateCalcUI();
    }

    public void memPlusClicked(View view) {
        calculator.memPlusClicked();
        updateCalcUI();
    }

    public void memMinusClicked(View view) {
        calculator.memMinusClicked();
        updateCalcUI();
    }

    public void memRClicked(View view) {
        calculator.memRClicked();
        updateCalcUI();
    }

    public void memCClicked(View view) {
        calculator.memCClicked();
        updateCalcUI();
    }

    public void percentClicked(View view) {
        calculator.percentClicked();
        updateCalcUI();
    }

    public void epowxClicked(View view) {
        calculator.epowxClicked();
        updateCalcUI();
    }

    public void piClicked(View view) {
        calculator.piClicked();
        updateCalcUI();
    }







    public void plusClicked(View view) {
        calculator.processOperator(Calculator.Operator.ADD);
        updateCalcUI();
    }

    public void equalClicked(View view) {
        calculator.processEqual();
        updateCalcUI();
    }

    public void minusClicked(View view) {
        calculator.processOperator(Calculator.Operator.SUBTRACT);
        updateCalcUI();
    }

    public void mulClicked(View view) {
        calculator.processOperator(Calculator.Operator.MULTIPLY);
        updateCalcUI();
    }

    public void divClicked(View view) {
        calculator.processOperator(Calculator.Operator.DIVIDE);
        updateCalcUI();
    }



}





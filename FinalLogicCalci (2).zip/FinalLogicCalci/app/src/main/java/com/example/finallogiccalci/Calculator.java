package com.example.finallogiccalci;



public class Calculator {
    String numberString = "0";
    String detailsString = "";
    long intNumber;
    double realNumber;
    boolean isIntNumber = true;
    boolean numHasRadixPoint = false;
    long memoryInt = 0;
    double memoryDouble = 0.0;
    boolean isIntMemory = true;

    public enum Operator {
        ADD, SUBTRACT, MULTIPLY, DIVIDE
    }

    Operator currentOperator;
    double firstOperand;

    public Calculator() {

    }


        public void processNumber ( int i){
            if (numberString.length() < 12) {  // limit of 12 digits
                intNumber = intNumber * 10 + i;
                numberString = String.valueOf(intNumber);
                detailsString = "Clicked: " + i;
            } else
                detailsString = "The number is too long..";
        }

        public void clearClicked () {
            numberString = "0";
            detailsString = "";
            intNumber = 0;
            realNumber = 0.0;
            isIntNumber = true;
            numHasRadixPoint = false;
        }


        public void memPlusClicked () {
            if (isIntMemory) {
                if (isIntNumber) {
                    memoryInt += intNumber;
                    detailsString = "Memory: " + memoryInt;
                } else {
                    isIntNumber = false;
                    memoryDouble = memoryInt + realNumber;
                }
            }
        }

    public void memMinusClicked() {
        if (isIntMemory) {
            if (isIntNumber) {
                memoryInt -= intNumber;
                detailsString = "Memory: " + memoryInt;
            } else {
                isIntNumber = false;
                memoryDouble = memoryInt - realNumber;
            }
        }
    }

    public void memRClicked() {
        if (isIntMemory) {
            numberString = String.valueOf(memoryInt);
            detailsString = "Memory recalled: " + memoryInt;
            intNumber = memoryInt;
            realNumber = 0.0;
            isIntNumber = true;
        } else {
            numberString = String.valueOf(memoryDouble);
            detailsString = "Memory recalled: " + memoryDouble;
            realNumber = memoryDouble;
            intNumber = 0;
            isIntNumber = false;
        }
    }

    public void memCClicked() {
        memoryInt = 0;
        memoryDouble = 0.0;
        isIntMemory = true;
        detailsString = "Memory cleared";
    }

    public void percentClicked() {
        if (isIntNumber) {
            realNumber = intNumber * 0.01;
        } else {
            realNumber *= 0.01;
        }
        numberString = String.valueOf(realNumber);
        detailsString = "Percentage calculated";
    }

    public void epowxClicked() {
        double x = isIntNumber ? intNumber : realNumber;
        double result = Math.exp(x);
        if (result % 1 == 0) {
            numberString = String.valueOf((int) result);
        } else {
            numberString = String.valueOf(result);
        }
        detailsString = "e^x calculated";
        realNumber = result;
        isIntNumber = false;
    }

    public void piClicked() {
        double piValue = Math.PI;
        numberString = String.valueOf(piValue);
        detailsString = "π (pi) inserted";
        realNumber = piValue;
        isIntNumber = false;
    }






    public void processOperator(Operator operator) {
        this.currentOperator = operator;
        this.firstOperand = this.isIntNumber ? this.intNumber : this.realNumber;
        this.numberString = "0";
        this.intNumber = 0;
        this.realNumber = 0.0;
        this.isIntNumber = true;
    }

    public void processEqual() {
        double secondOperand = this.isIntNumber ? this.intNumber : this.realNumber;
        switch (this.currentOperator) {
            case ADD:
                this.realNumber = this.firstOperand + secondOperand;
                break;
            case SUBTRACT:
                this.realNumber = this.firstOperand - secondOperand;
                break;
            case MULTIPLY:
                this.realNumber = this.firstOperand * secondOperand;
                break;
            case DIVIDE:
                this.realNumber=this.firstOperand / secondOperand;
                break;
            // Add cases for other operators here
        }
        if (this.realNumber % 1 == 0) {
            this.numberString = String.valueOf((int) this.realNumber);
        } else {
            this.numberString = Double.toString(this.realNumber);
        }
        this.isIntNumber = false;
    }









}
